#include"Character.h"
#include<iostream>
Character::Character()
{
}

Character::Character(LTexture* image, float x, float y, int ascii)
{
    spriteSheetTexture = image;
    spriteClips.w = 30;
    spriteClips.h = 43;

    int diff=0;

    ///selects the Character image according to its ascii value
    if(ascii==32)//space
    {
        spriteClips.x=252;
        spriteClips.y=355;
        spriteClips.w=8;
    }
    else if(ascii>=48 && ascii<=57)//numbers
    {
        character_value=48;//first ascii
        spriteClips.x = 38;
        spriteClips.y = 235;

        diff=ascii-character_value;
//        if (diff>7)//for numbers in the line below on font sprite
//        {
//            spriteClips.x = 0;
//            spriteClips.y +=41;
//            character_value+=8;//since next line of numbers starts from 8
//            diff=ascii-character_value;
//        }
        spriteClips.x+=35*diff;
    }
//    else if(ascii==63)//for question mark
//    {
//        spriteClips.x=252;
//        spriteClips.y=224;
//    }
    else if((ascii>=65 && ascii<=90) || (ascii>=97 && ascii<=122))//for alphabets
    {
        if((ascii>=97) && (ascii<=122))//if small letters, convert ascii to capital letters
        {
            ascii-=32;
        }
        character_value = 65;
        spriteClips.x = 0;
        spriteClips.y = 13;
        diff=ascii-character_value;
        spriteClips.y +=75*(diff/17);
        character_value+=17*(diff/17);
        diff=ascii-character_value;
        spriteClips.x+=35*diff;
    }

    character_value=ascii;

    position.x = x;
    position.y = y;

    this->width = spriteClips.w;
    this->height = spriteClips.h;
}

Character::~Character()
{
    /*char n = character_value + 97;
    std::cout<<"\nCharacter "<<n<<" Destroyed";*/
}

void Character::Render( SDL_Renderer* gRenderer, bool debug)
{

    spriteSheetTexture->RenderTexture( position.x - width/2, position.y - height/2, gRenderer, &spriteClips);
    if(debug == true)
    {
        SDL_Rect rect = { position.x - width/2, position.y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

void Character::operator = (const Character& cpy)
{
    this->position=cpy.position;
    this->spriteClips=cpy.spriteClips;

    this->spriteSheetTexture=cpy.spriteSheetTexture;
    this->character_value=cpy.character_value;
    this->width=cpy.width;
    this->height=cpy.height;
}
