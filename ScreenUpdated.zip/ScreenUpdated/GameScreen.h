#pragma once
#include "Screen.h"
#include <SDL.h>
//include all objects on screen i.e. cars, students, player  van
class GameScreen:public Screen
{
public:
    GameScreen(LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~GameScreen();
};
