#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "LTexture.h"
#include "Screen.h"
#include "StartScreen.h"
#include "MenuScreen.h"
#include "InstructionScreen.h"
#include "GameOverScreen.h"
#include "PauseScreen.h"
#include "GameScreen.h"
#include "QuitScreen.h"
#include "Button.h"
#include <SDL_mixer.h>
using namespace std;

bool init();
bool loadMedia();
void close();
void setAlpha();

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

const int SCREEN_WIDTH =  1024;
const int SCREEN_HEIGHT = 768;

//Textures for images
LTexture gFontTexture;
LTexture gStart;//start('OOP Project') image
LTexture gMainMenuTexture;
LTexture gInstructionTexture;
LTexture gGameOverTexture;
LTexture gButtonBorder;//for pause screen
LTexture gQuitTexture;

//musics
Mix_Music* MenuScreenMusic= NULL;
Mix_Music* gameMusic= NULL;
Mix_Music* InstructionScreenMusic= NULL;
Mix_Chunk* ButtonClickSsound= NULL;
Mix_Music* game_over = NULL;

//Alpha(Opacity) Modulation component
Uint8 a = 255; //one component is set to full opaque
Uint8 b = 0; //other is full transparent
Uint8 button = 220;//alpha value for buttons
Uint8 button_screen = 200; //for controlling alpha value of other textures


int main( int argc, char* args[] )
{
    if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
			//Main loop flag
			bool quit = false;
            //flags to check which screen is running

            bool StartRunning = true;
            bool menuRunning = false;
            bool instructionRunning = false;
            bool gameOverRunning = false;
            bool pauseRunning = false;
            bool quitRunning = false;
            bool gameRunning = false;

            long int frame = 0;

            bool mouseClicked = false; //flag indicating mouse click
            Button* buttons = NULL;   //will hold button(s) on the screen
            int x,y;


            StartScreen Start(&gStart,&gFontTexture);
            MenuScreen mainMenu(&gMainMenuTexture,&gFontTexture/*,&gButtonScreen*/);
            InstructionScreen instructionMenu(&gInstructionTexture,&gFontTexture);
            GameOverScreen gameOver(&gGameOverTexture,&gFontTexture/*,&gButtonScreen*/);
            PauseScreen PauseScreen(&gButtonBorder,&gFontTexture);
            QuitScreen QuitScreen(&gQuitTexture,&gFontTexture);
            GameScreen GameScreen(&gFontTexture);

			//Event handler
			SDL_Event e;
			//While application is running
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
					SDL_GetMouseState(&x,&y);
                    if (e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                            mouseClicked=true;
                    }
                    if (e.type == SDL_MOUSEMOTION) //to handle all mouse motion events for all screens
                    {
                        mainMenu.mouseMotionEvents(x,y);
                        gameOver.mouseMotionEvents(x,y);
                        PauseScreen.mouseMotionEvents(x,y);
                        QuitScreen.mouseMotionEvents(x,y);
                        GameScreen.mouseMotionEvents(x,y);
                        instructionMenu.mouseMotionEvents(x,y);
                    }
                    if(e.type == SDL_MOUSEBUTTONUP && mouseClicked) //to handle all mouse click events for all screens
                    {
                        mainMenu.mouseClickEvents(x,y,ButtonClickSsound);
                        gameOver.mouseClickEvents(x,y, ButtonClickSsound);
                        PauseScreen.mouseClickEvents(x,y,ButtonClickSsound);
                        QuitScreen.mouseClickEvents(x,y,ButtonClickSsound);
                        GameScreen.mouseClickEvents(x,y,ButtonClickSsound);
                        instructionMenu.mouseClickEvents(x,y,ButtonClickSsound);
                        mouseClicked = false;
                    }
                    if (menuRunning)
                    {
                        buttons = mainMenu.getButtons();
                        for (int i = 0; i < mainMenu.getButtonCount(); i++)
                        {
                            if(buttons[i].getText() == "NEW GAME" && buttons[i].clicked())
                            {
                                //game screen will load
                                cout<<"new game button"<<endl;
                                instructionRunning= true;
                                menuRunning=false;
                                break;
                            }
                            else if (buttons[i].getText() == "CONTINUE" && buttons[i].clicked())
                            {
                                //loaded game will run
                                menuRunning = false;
                                gameRunning=true;//game screen runs with game
                                break;

                            }
                            else if (buttons[i].getText() == "EXIT"  && buttons[i].clicked())
                            {
                                quit=true;
                                break;
                            }
                            else if (buttons[i].getText() == "MUSIC"  && buttons[i].clicked())
                            {
                                if( Mix_PausedMusic() == 1 )
                                {
                                    //Resume the music
                                    Mix_ResumeMusic();
                                }
                                //If the music is playing
                                else
                                {
                                    //Pause the music
                                    Mix_PauseMusic();
                                }
                                break;
                            }
                        }
                    }
                    if (instructionRunning)
                    {
                        buttons = instructionMenu.getButtons();
                        if(buttons[0].clicked())//the button will pause the game
                        {
                            Mix_PauseMusic();
                            instructionRunning=false;
                            gameRunning = true;
                            break;
                        }
                        if(buttons[1].clicked())//the button will pause the game
                        {
                            if( Mix_PausedMusic() == 1 )
                                {
                                    //Resume the music
                                    Mix_ResumeMusic();
                                }
                                //If the music is playing
                                else
                                {
                                    //Pause the music
                                    Mix_PauseMusic();
                                }
                                break;
                        }

                    }
                    if (gameRunning)
                    {
                        buttons = GameScreen.getButtons();
                        if(buttons[0].clicked())//the button will pause the game
                        {
                            pauseRunning = true;
                            break;
                        }
                        if(buttons[1].clicked())//the button will pause the game
                        {
                            if( Mix_PausedMusic() == 1 )
                                {
                                    //Resume the music
                                    Mix_ResumeMusic();
                                }
                                //If the music is playing
                                else
                                {
                                    //Pause the music
                                    Mix_PauseMusic();
                                }
                                break;
                        }
                    }
                    if (quitRunning)
                    {
                        buttons = QuitScreen.getButtons();
                        for(int i=0; i < QuitScreen.getButtonCount(); i++)   //loop going through each button index
                        {
                            if(buttons[i].getText() == "YES" && buttons[i].clicked())
                            {
                                //save the game
                                //game.SaveGame();
                                quitRunning = false;
                                gameRunning = false;
                                menuRunning = true;
                                break;
                            }
                            else if (buttons[i].getText() == "NO" && buttons[i].clicked())
                            {
                                //don't save the game
                                quitRunning = false;
                                gameRunning = false;
                                menuRunning = true;
                                break;
                            }
                            else if (buttons[i].getText() == "CANCEL" && buttons[i].clicked())
                            {
                                quitRunning = false;
                                break;
                            }
                        }
                    }
                    if (pauseRunning)
                    {
                        buttons = PauseScreen.getButtons();
                        for(int i=0; i < PauseScreen.getButtonCount(); i++)   //loop going through each button index
                        {
                            if(buttons[i].getText() == "RESUME" && buttons[i].clicked())
                            {
                                pauseRunning = false;
                                break;
                            }
                            else if (buttons[i].getText() == "RESTART" && buttons[i].clicked())
                            {
                                pauseRunning = false;
                                //game will restart
                                break;
                            }
                            else if (buttons[i].getText() == "QUIT" && buttons[i].clicked())
                            {
                                quitRunning = true;
                                pauseRunning = false;
                                break;
                            }
                        }
                    }
                    if (gameOverRunning)
                    {
                        buttons = gameOver.getButtons();
                        for(int i=0; i < gameOver.getButtonCount(); i++)   //loop going through each button index
                        {
                            if(buttons[i].getText() == "MAIN MENU" && buttons[i].clicked())
                            {
                                gameOverRunning = false;
                                menuRunning = true;
                                break;
                            }
                            else if (buttons[i].getText() == "PLAY AGAIN" && buttons[i].clicked())
                            {
                                gameOverRunning = false;
                                gameRunning = true;
                                //game.Restart();
                                break;
                            }
                            else if (buttons[i].getText() == "EXIT" && buttons[i].clicked())
                            {
                                quit = true;
                                break;
                            }
                        }
                    }
				}
                //Clear screen
				SDL_SetRenderDrawColor( gRenderer,  0, 0, 0, 0 );
				SDL_RenderClear( gRenderer );

                if(menuRunning)     //checks if Main Menu Screen is running
                {
                    //if transition to excerpt is called, start fading the menu-screen.
                    Mix_PlayMusic(MenuScreenMusic,-1);
                    MenuScreenMusic = false;
//                    if (MenuScreenMusic)
//                    {
//                        Mix_PlayMusic(MenuScreenMusic,-1);
//                        MenuScreenMusic = false;
//                    }
                    //gFontTexture.setAlpha(button);
                    //gMainMenuTexture.setAlpha(a);

                    mainMenu.Render(frame,gRenderer); //render main menu
                }
                if(StartRunning)       //checks if Start screen is running
                {
                    gStart.setAlpha(a);     //Start Screen fades out with a decreasing alpha value
                    Start.Render(frame, gRenderer);       //Rendering Screen
                    if(a == 0)
                    {
                        //Mix_PlayChannel(-1, screenTransition, 0);
                        StartRunning = false;    //indicates the end of the screen run
                        menuRunning = true;
                        a = 255; //reset
                        b = 0; //reset
                    }
                }
                if (quitRunning)
                {
                    QuitScreen.Render(frame,gRenderer);
                }
                if(instructionRunning)//if instruction screen is running
                {
                    //cout<<"instruction running"<<endl;
                    //gInstructionTexture.setAlpha(b);
                    instructionMenu.Render(frame, gRenderer);       //Rendering the instruction Screen
                    //Mix_PlayMusic(InstructionScreenMusic,1);
                    Mix_PlayMusic(InstructionScreenMusic,-1);
                    InstructionScreenMusic= false;
//
                }
                if(gameRunning) //transition between Game screen and Excerpt
                {
                    GameScreen.Render(frame,gRenderer);
                    Mix_PlayMusic(gameMusic,-1);
                    gameMusic= false;

                }
                if (pauseRunning)
                {
                    PauseScreen.Render(frame,gRenderer);
                }
                if (quitRunning)
                {
                    QuitScreen.Render(frame,gRenderer);
                }
                if (gameOverRunning)
                {
//                        if (gameOverMusic)
//                        {
//                                Mix_PlayMusic(game_over,0);
//                                //gameOverMusic = false; //play game over music only once
//                        }
//                        if (b > 170)
//                        {
//                                //gButtonScreen.setAlpha(button);
//                        }
//                        else
//                        {
//                            gFontTexture.setAlpha(b);
//                        }
                        //gGameOverTexture.setAlpha(b);
                        gameOver.Render(frame,gRenderer);
                }

                setAlpha(); //to decrement a and increment b
                frame++;
                if (frame % 50 == 0)
                {
                    frame = 0;
                }
				//Update screen
				SDL_RenderPresent( gRenderer );
			}
		}
	}
	//Free resources and close SDL
	close();
    return 0;

}

bool init()
{
	///Initialization flag
	bool success = true;

	///Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		///Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		///Create window
		gWindow = SDL_CreateWindow( "Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}

		else
		{
			///Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
			else
			{
				///Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0 );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
                //Initialize SDL_mixer
                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
                {
                    printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
                    success = false;
                }
			}
		}
	}
	return success;
}

bool loadMedia()
{
	///Loading success flag
	bool success = true;
	if( !gFontTexture.LoadFromFile( "font.png", gRenderer) )//button and text sprite sheet
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        //Set standard alpha blending
        gFontTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !gStart.LoadFromFile( "startscreen.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gStart.setBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !gQuitTexture.LoadFromFile( "QuitScreen1.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
    if( !gButtonBorder.LoadFromFile( "screen2.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

    if( !gInstructionTexture.LoadFromFile( "instr.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gInstructionTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
	if( !gMainMenuTexture.LoadFromFile( "vav.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gMainMenuTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !gGameOverTexture.LoadFromFile( "gameoverscreen.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
    //Sound effects loading
    MenuScreenMusic = Mix_LoadMUS( "pacman_intermission.wav" );
    if( MenuScreenMusic == NULL )
    {
        printf( "Failed to load menu screen sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    gameMusic = Mix_LoadMUS( "gameMusic.wav" );
    if( gameMusic == NULL )
    {
        printf( "Failed to load menu screen sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    InstructionScreenMusic = Mix_LoadMUS( "coolgames.wav" );
    if( MenuScreenMusic == NULL )
    {
        printf( "Failed to load menu screen sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    ButtonClickSsound  = Mix_LoadWAV( "button_click.wav" );
    if( ButtonClickSsound == NULL )
    {
        printf( "Failed to load buttonClick sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    return success;
}

void close()
{
	///Free loaded images
    //gFontTexture.Free();
	gStart.Free();
    gMainMenuTexture.Free();
    Mix_FreeChunk( ButtonClickSsound );
    ButtonClickSsound = NULL;
    Mix_FreeMusic( MenuScreenMusic );
    MenuScreenMusic = NULL;
    Mix_FreeMusic( InstructionScreenMusic );
    InstructionScreenMusic = NULL;
	///Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	///Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}
void setAlpha()
{
    ///Cap if below 0
    if( a - 3 < 0 )
    {
        a = 0;
    }
    ///Decrement otherwise
    else
    {
        a -= 3;
    }
    ///Cap if above 255
    if( b+ 3 > 255 )
    {
        b=255;
    }
    ///Increment otherwise
    else
    {
        b += 3;
    }
}
