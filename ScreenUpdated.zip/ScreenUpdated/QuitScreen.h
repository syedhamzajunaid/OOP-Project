#pragma once
#include "Screen.h"

class QuitScreen:public Screen
{
private:
    Point position; //position of Quit Screen on the whole screen
    int qWidth;
    int qHeight;
    Word* word;
public:
    QuitScreen(LTexture*,LTexture*);
    void Render(long int& frame, SDL_Renderer*);
    virtual ~QuitScreen();
};
