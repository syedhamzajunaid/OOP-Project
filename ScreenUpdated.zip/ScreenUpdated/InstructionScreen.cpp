#include "InstructionScreen.h"
InstructionScreen::InstructionScreen(LTexture* bgImage,LTexture* fontSprite) : Screen(bgImage,fontSprite)
{
    this->bgImage=bgImage;
    ButtonCount = 2;
    buttons = new Button[2];
    buttons[0] = Button (fontSprite,"NEXT",840,height-70);
    buttons[1] = Button (fontSprite,"MUSIC",100,40);
}

void InstructionScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    std::cout<<"Instruction screen coming"<<std::endl;
    bgImage->RenderTexture( 0, 0,gRenderer,NULL);
    buttons[0].Render(gRenderer);
    buttons[1].Render(gRenderer);
}

InstructionScreen::~InstructionScreen()
{
    std::cout<<"Instruction screen Destroyed"<<std::endl;
}

