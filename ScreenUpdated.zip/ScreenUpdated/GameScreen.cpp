#include "GameScreen.h"
#include <iostream>
using namespace std;
GameScreen::GameScreen(LTexture* fontSprite) : Screen(NULL,fontSprite)
{
    ButtonCount = 2;
    buttons = new Button[2];
    buttons[0] = Button (fontSprite,"PAUSE",130,height-30);
     buttons[1] = Button (fontSprite,"MUSIC",850,height-30);
}

void GameScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    buttons[0].Render(gRenderer);
    buttons[1].Render(gRenderer);
}
GameScreen::~GameScreen()
{
    std::cout << "Game Screen Destroyed" << std::endl;
}

