#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include "GameLoop.h"
#include "Map.h"
#include "LTexture.h"
#include "StartScreen.h"
#include "Button.h"

using namespace std;
GameLoop *game = NULL;

int main(int argc, char *argv[])
{
    //LTexture gFontTexture;
    //gStart.LoadTexture("Assets/Map.png");
    //gFontTexture.LoadTexture("Assets/Player.png");
    //StartScreen Start(&gStart,&gFontTexture);

    game = new GameLoop();
    game->init("Please work", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 640, false);
    while(game->is_running())
    {
        //game->handleevents();
        //game->update();
        game->render();
    }


    game->close();

    return 0;
}
