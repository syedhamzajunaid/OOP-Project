#pragma once
#include "LTexture.h"
#include "Button.h"
#include <SDL_mixer.h>


class Screen
{
protected:
    SDL_Texture* bgTexture;
    SDL_Texture* fontSpriteTexture;
    int ButtonCount = 0;   //no. of Buttons to be rendered
    Button* buttons = NULL; //pointer of Button class(either kept null or used to create dynamic array of buttons)
    const int width =  1024;
    const int height = 768;
    int xpos, ypos;
public:
    Screen();
    Screen(const char* spritesheet1, const char* spritesheet2);
    ~Screen();
    void Update();
    virtual void Render();
    Button* getButtons();   //returns array of buttons
    int getButtonCount();   //return the no. of buttons to be rendered
    void ChangeButtonState(State val, int ind); //changes the state of Button on the index
    void mouseMotionEvents(int x, int y); //used to handle mouse motion events on a screen
    void mouseClickEvents(int x, int y,Mix_Chunk* buttonClick); //used to handle mouse click events on a screen
};

