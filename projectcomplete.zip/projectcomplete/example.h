#pragma once

//#include "Screen.h"

class example
{
public:
    example(const char* pathBgImage, const char* pathFontsprite);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~example();
};
