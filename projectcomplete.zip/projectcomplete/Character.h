#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#pragma once
#include <iostream>
#include"LTexture.h"
#include"Point.h"

class Character
{
private:
    Point position; //Position of the Character
    int character_value = 0; //ascii value of the Character
    int width; //width of character
    int height; //height of character
    SDL_Rect spriteClips; //clip specific to the Character
    SDL_Texture* spriteSheetTexture; //font image
    SDL_Rect destrect;
public:
    Character();
    Character(const char* spritesheet, int x, int y, int ascii);
    ~Character();
    void Render();
    void operator = (const Character& cpy); //operator overloading for assignment operatot
};

