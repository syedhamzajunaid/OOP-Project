#pragma once
#include "Screen.h"

class StartScreen : public Screen
{
public:
    StartScreen(const char* path1, const char* path2);//paths for bgimage and fontsprite
     void Render();
    ~StartScreen();
};
