#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>

//Texture wrapper class
class LTexture
{
    public:
        static SDL_Texture* newTexture;
        int width;
        int height;
        LTexture();
        ~LTexture();

        static SDL_Texture* LoadTexture(const char*);
        void RenderTexture(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE, double angle = 0.0, SDL_Point* center = NULL, float scale = 1);

        //static void Draw(SDL_Texture *tex, SDL_Rect src, SDL_Rect dest);
};
