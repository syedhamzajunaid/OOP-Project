#include "example.h"


example::example(const char* pathBgImage, const char* pathFontsprite)
{
    this->bgImage=bgImage;
}

void example::Render(long int& frame,SDL_Renderer* gRenderer)
{
     bgImage->RenderTexture( 0, 0,gRenderer,NULL);
}

example::~example()
{
    std::cout<<"Splash Screen Destroyed"<<std::endl;
}
