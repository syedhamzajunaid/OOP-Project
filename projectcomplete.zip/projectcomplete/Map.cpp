#include "Map.h"
#include "LTexture.h"


Map::Map(const char* spritesheet)
{
    map_texture = LTexture::LoadTexture(spritesheet);
    blocks[0].x = blocks[0].y = 0;
    blocks[0].w = 125;
    blocks[0].h = 72;

    blocks[1].x = 150;
    blocks[1].y = 0;
    blocks[1].w = 80;
    blocks[1].h = 72;

    blocks[2].x = 260;
    blocks[2].y = 0;
    blocks[2].w = 130;
    blocks[2].h = 72;

    blocks[3].x = 420;
    blocks[3].y = 0;
    blocks[3].w = 100;
    blocks[3].h = 72;

    blocks[4].x = 550;
    blocks[4].y = 0;
    blocks[4].w = 80;
    blocks[4].h = 72;

    blocks[5].x = 660;
    blocks[5].y = 0;
    blocks[5].w = 140;
    blocks[5].h = 160;

    blocks[6].x = 410;
    blocks[6].y = 97;
    blocks[6].w = 210;
    blocks[6].h = 63;

    blocks[7] = {280, 97, 100, 160};
    blocks[8] = {90, 96, 160, 55};
    blocks[9] = {0, 98, 61, 53};
    blocks[10] = {30, 178, 90, 55};
    blocks[11] = {30, 258, 219, 22};
    blocks[12] = {150, 177, 100, 76};
    blocks[13] = {410, 185, 60, 48};
    blocks[14] = {500, 185, 59, 48};
    blocks[15] = {590, 185, 40, 48};
    blocks[16] = {500, 185, 59, 48};
    blocks[17] = {500, 185, 59, 48};
    blocks[18] = {660, 185, 111, 71};
    blocks[19] = {660, 185, 111, 71};
    blocks[20] = {660, 280, 140, 94};
    blocks[21] = {410, 255, 70, 65} ;
}

Map::~Map()
{}

void Map::Update()
{
    xpos = ypos = 0;
}

void Map::Render()
{
    SDL_RenderCopy(GameLoop::grenderer, map_texture, NULL, NULL);
    /*
    for(int i = 0; i < 22; i++)
    {
    SDL_SetRenderDrawColor(GameLoop::grenderer, 0xFF, 0x00, 0x00, 0xFF);
    SDL_RenderFillRect(GameLoop::grenderer, &(blocks[i]));
    }
    */

}

