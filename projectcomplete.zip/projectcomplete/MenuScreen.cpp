#include "MenuScreen.h"
#include "Button.h"
#include "GameLoop.h"


MenuScreen::MenuScreen(const char* path1, const char* path2) : Screen("Assets/startscreen.png", "Assets/font.png")
{
    bgTexture = LTexture::LoadTexture(path1);
    std::cout<<"bgtexture"<<endl;
    fontSpriteTexture = LTexture::LoadTexture(path2);
    std::cout<<"fonttexture"<<endl;
    //std::string ButtonText[4]={"CONTINUE", "NEW GAME","EXIT","MUSIC"}; //Text on the buttons
    std::string ButtonText[1]={"CONTINUE"};
    std::cout<<"buttontext"<<endl;
    float posX=(float)width/2;
    float posY=((float)height/2);
    ButtonCount = 1;
    //buttons = new Button[4];
    buttons = new Button[1];
    std::cout<<"new button"<<endl;
    for(int i=0; i<1; i++)
    {
        buttons[i] = Button("Assets/font.png","CONTINUE",100, 300);
        std::cout<<"button"<<endl;
    }

}

void MenuScreen::Render()
{
    SDL_RenderCopyEx(GameLoop::grenderer, bgTexture, NULL, NULL, NULL, NULL, SDL_FLIP_NONE);
    std::cout<<"bg render"<<endl;
    for(int i=0; i<1; i++)
    {
        buttons[i].Render();
        std::cout<<"button render"<<endl;
    }
}

MenuScreen::~MenuScreen()
{
    std::cout<<"Menu Screen Destroyed"<<endl;
}

