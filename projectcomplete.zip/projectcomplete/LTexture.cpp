#include "LTexture.h"
#include "GameLoop.h"

LTexture::LTexture()
{
}

LTexture::~LTexture()
{
}

SDL_Texture* LTexture::LoadTexture(const char* path)
{
    //The final texture
    //SDL_Texture*
    SDL_Texture* newTexture;
    newTexture = NULL;

    //Load image at specified path
    SDL_Surface* loadedSurface = IMG_Load(path);
    if( loadedSurface == NULL )
    {
        printf( "Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError() );
    }
    else
    {
        //Color key image
        SDL_SetColorKey( loadedSurface, SDL_TRUE, SDL_MapRGB( loadedSurface->format, 0, 0xFF, 0xFF ) );
        //Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( GameLoop::grenderer, loadedSurface );
        if( newTexture == NULL )
        {
            printf( "Unable to create texture from %s! SDL Error: %s\n", path, SDL_GetError() );
        }
        //Get rid of old loaded surface
        SDL_FreeSurface( loadedSurface );
    }
    //LTexture::texture = newTexture;
    if(newTexture != NULL)
    {
        std::cout << "returning texture" << endl;
        return newTexture;
    }
}

void LTexture::RenderTexture(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip, SDL_RendererFlip flip, double angle, SDL_Point* center,float scale)
{
    SDL_Rect rectCoordinates = {x, y, width, height};

    if(clip != NULL)
    {
        rectCoordinates.w = clip->w;
        rectCoordinates.h = clip->h;
    }
    rectCoordinates.w *= scale;
    rectCoordinates.h *= scale;
    //texture = LTexture::LoadTexture(path);
    SDL_Texture* newTexture;
    cout<<&newTexture<<endl;
    SDL_RenderCopyEx(gRenderer, newTexture, clip, &rectCoordinates, angle, center, flip);
    //SDL_RenderPresent(gRenderer);
}

