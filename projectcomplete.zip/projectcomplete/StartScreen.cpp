#include "StartScreen.h"
#include "GameLoop.h"

StartScreen::StartScreen(const char* path1, const char* path2) : Screen("Assets/startscreen.png", "Assets/goldCoin1.png")
{
    bgTexture = LTexture::LoadTexture(path1);
    //fontSpriteTexture = LTexture::LoadTexture(path2);
}

void StartScreen::Render()
{
     SDL_RenderCopyEx(GameLoop::grenderer, bgTexture, NULL, NULL, NULL, NULL, SDL_FLIP_NONE);
}

StartScreen::~StartScreen()
{
    std::cout<<"Splash Screen Destroyed"<<std::endl;
}


