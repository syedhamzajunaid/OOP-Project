#pragma once
#include "Screen.h"

class MenuScreen : public Screen
{
public:
     MenuScreen(const char* path1, const char* path2);//paths for bgimage and fontsprite
     void Render();
    ~MenuScreen();

};
