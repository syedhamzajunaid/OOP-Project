#include "GameObject.h"
#include "Map.h"

GameObject::GameObject(){}

GameObject::GameObject(const char* spritesheet)
{
    objTexture = LTexture::LoadTexture(spritesheet);
    xpos = 0;
    ypos = 75;
    destrect.x = xpos;
    destrect.y = ypos;
    destrect.w = 10;
    destrect.h = 20;
    angle = 90;
    collision = false;
}

GameObject::~GameObject()
{
    SDL_DestroyTexture(objTexture);
    objTexture = NULL;
}


void GameObject::Update(SDL_Event e, SDL_Rect* blocks)
{
    if (e.type = SDL_KEYDOWN)
    {
        cout << collision << endl;

        if(e.key.keysym.sym == SDLK_LEFT)
            {
                if(angle != -90)
                {
                    angle = -90;
                }
                xpos = (xpos - 2);
                destrect.x = xpos;
                for(int i = 0; i < 22; i++)
                {
                    if(GameObject::check_collision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    xpos = xpos + 2;
                    destrect.x = xpos;
                    collision = false;
                }
            }
       else if(e.key.keysym.sym == SDLK_RIGHT)
            {
                if(angle != 90)
                {
                    angle = 90;
                }
                xpos = xpos + 2;
                destrect.x = xpos;
                for(int i = 0; i < 20; i++)
                {
                    if(GameObject::check_collision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    xpos = xpos - 2;
                    destrect.x = xpos;
                    collision = false;
                }
            }
        else if(e.key.keysym.sym == SDLK_UP)
            {
                if(angle != 0)
                {
                    angle = 0;
                }
                ypos = ypos - 2;
                destrect.y = ypos;
                for(int i = 0; i < 20; i++)
                {
                    if(GameObject::check_collision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    ypos = ypos + 2;
                    destrect.y = ypos;
                    collision = false;
                }
            }
        else if(e.key.keysym.sym == SDLK_DOWN)
            {
                if(angle != 180)
                {
                    angle = 180;
                }
                ypos = ypos + 2;
                destrect.y = ypos;
                for(int i = 0; i < 20; i++)
                {
                    if(GameObject::check_collision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    ypos = ypos - 2;
                    destrect.y = ypos;
                    collision = false;
                }
            }
    }

}

void GameObject::Render()
{
    SDL_RenderCopyEx(GameLoop::grenderer, objTexture, NULL, &destrect, angle, NULL, SDL_FLIP_NONE);
}

bool GameObject::check_collision( SDL_Rect B, SDL_Rect A )
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect A
    leftA = A.x;
    rightA = A.x + A.w;
    topA = A.y;
    bottomA = A.y + A.h;

    leftB = B.x;
    rightB = B.x + B.w;
    topB = B.y;
    bottomB = B.y + B.h;
    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }
    //If none of the sides from A are outside B
    return true;
}

