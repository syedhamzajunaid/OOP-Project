#include "Screen.h"
#include "GameLoop.h"
#include <iostream>
using namespace std;

Screen::Screen(){}

Screen::Screen(const char* spritesheet1, const char* spritesheet2)
{
    bgTexture = LTexture::LoadTexture(spritesheet1);
    fontSpriteTexture = LTexture::LoadTexture(spritesheet2);

}

Screen::~Screen()
{
    SDL_DestroyTexture(bgTexture);
    SDL_DestroyTexture(fontSpriteTexture);
    bgTexture = NULL;
    fontSpriteTexture= NULL;

    if (buttons != NULL)
    {
        delete[] buttons;
        buttons = NULL;
    }
    std::cout <<  "Screen destructed" << std::endl;
}


Button* Screen::getButtons()  //returns array of buttons
{
    return buttons;
}
int Screen::getButtonCount() //return the no. of buttons rendered
{
    return ButtonCount;
}
void Screen::ChangeButtonState(State val, int ind) //changes the state of Button on the index
{
    buttons[ind].changeState(val);
}
void Screen::mouseMotionEvents(int x, int y)
{
    for(int i=0; i < ButtonCount; i++)
    {
        int posX=buttons[i].getPosition().x;
        int posY=buttons[i].getPosition().y;
        //checks if the pointer position lie inside the border of the button
        //then change the state to hover, else to normal

        if((x<=posX+buttons[i].getWidth()/2 && x>=posX-buttons[i].getWidth()/2)&&(y<=posY+buttons[i].getHeight()/2 && y>=posY-buttons[i].getHeight()/2))
        {
            ChangeButtonState(Hover,i);

        }
        else
        {
            ChangeButtonState(Normal,i);

        }
    }
}
void Screen::mouseClickEvents(int x, int y,Mix_Chunk* ButtonClickSound)
{
    for(int i=0; i < ButtonCount; i++) //loop going through each button index
    {
        int posX=buttons[i].getPosition().x;
        int posY=buttons[i].getPosition().y;
        //checks if the pointer position lie inside the border of the button and mouse is clicked
        //then change the state to clicked
        if((x<=posX+buttons[i].getWidth()/2 && x>=posX-buttons[i].getWidth()/2)&&(y<=posY+buttons[i].getHeight()/2 && y>=posY-buttons[i].getHeight()/2))
        {
            Mix_PlayChannel(-1, ButtonClickSound, 0);
            cout<<"a button is clicked"<<endl;
            ChangeButtonState(Clicked,i);
        }
    }
}

void Screen::Render()
{
    SDL_RenderCopyEx(GameLoop::grenderer, bgTexture, NULL, NULL, NULL, NULL, SDL_FLIP_NONE);
    //SDL_RenderCopyEx(GameLoop::grenderer, fontSpriteTexture, NULL, &destrect, angle, NULL, SDL_FLIP_NONE);

}
void Screen::Update()
{
    xpos = ypos = 5;
}
