#pragma once
#include "SDL.h"
#include "LTexture.h"

class Map
{
private:
	SDL_Rect map;
	int x = 0;
	int y = 0;

public:
	SDL_Rect* City_blocks;
	void create_rects_on_blocks()
	{
		City_blocks = new SDL_Rect[40];

		/*This includes the dimensions of 39 rects
			which overlap the city blocks on the map
			The values need to hardcoded, coordinates 
			can be found via Paint*/

		City_blocks[0] = { 0,0,154,86 };
		/*City_blocks[1] = { 0,0,0,0 };
		City_blocks[2] = { 0,0,0,0 };
		City_blocks[3] = { 0,0,0,0 };
		City_blocks[4] = { 0,0,0,0 };
		City_blocks[5] = { 0,0,0,0 };
		City_blocks[6] = { 0,0,0,0 };
		City_blocks[7] = { 0,0,0,0 };
		City_blocks[8] = { 0,0,0,0 };
		City_blocks[9] = { 0,0,0,0 };
		City_blocks[10] = { 0,0,0,0 };
		City_blocks[11] = { 0,0,0,0 };
		City_blocks[12] = { 0,0,0,0 };
		City_blocks[13] = { 0,0,0,0 };
		City_blocks[14] = { 0,0,0,0 };
		City_blocks[15] = { 0,0,0,0 };
		City_blocks[16] = { 0,0,0,0 };
		City_blocks[17] = { 0,0,0,0 };
		City_blocks[18] = { 0,0,0,0 };
		City_blocks[19] = { 0,0,0,0 };
		City_blocks[20] = { 0,0,0,0 };
		City_blocks[21] = { 0,0,0,0 };
		City_blocks[22] = { 0,0,0,0 };
		City_blocks[23] = { 0,0,0,0 };
		City_blocks[24] = { 0,0,0,0 };
		City_blocks[25] = { 0,0,0,0 };
		City_blocks[26] = { 0,0,0,0 };
		City_blocks[27] = { 0,0,0,0 };
		City_blocks[28] = { 0,0,0,0 };
		City_blocks[29] = { 0,0,0,0 };
		City_blocks[30] = { 0,0,0,0 };
		City_blocks[31] = { 0,0,0,0 };
		City_blocks[32] = { 0,0,0,0 };
		City_blocks[33] = { 0,0,0,0 };
		City_blocks[34] = { 0,0,0,0 };
		City_blocks[35] = { 0,0,0,0 };
		City_blocks[36] = { 0,0,0,0 };
		City_blocks[37] = { 0,0,0,0 };
		City_blocks[38] = { 0,0,0,0 };
		City_blocks[39] = { 0,0,0,0 };*/
	}

	Map(LTexture* image)
	{
		map.x = 0;
		map.y = 0;
		map.h = image->GetHeight();
		map.w = image->GetWidth();

		// This will create rects on the city blocks.
		create_rects_on_blocks();
	}
	~Map() {};
	void Render(LTexture* image, SDL_Renderer* gRenderer) 
	{
		image->RenderTexture(x, y, gRenderer,
			&map);

	}



















};