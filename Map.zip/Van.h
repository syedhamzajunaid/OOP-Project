#pragma once
#include "Map.h"
#include "SDL.h"

class van
{
private:
	int x, y; // position, have to be replaced with point
	SDL_Rect van_player;
	double angle=0.0; // for the dimension change

public:
	~van() {};
	van(LTexture* image)
	{
		van_player.h = 25;
		van_player.w = 30;
		van_player.x = 0;
		van_player.y = 51;

		this->x = 0;
		this->y = 89;
	}
	
	void Render(LTexture* image, SDL_Renderer* gRenderer)
	{
		image->RenderTexture(x, y, gRenderer,
			&van_player, SDL_FLIP_NONE, angle, NULL);
	}

	bool collision(SDL_Rect* blocks, SDL_Event e)
	{
		int leftA, leftB;
		int rightA, rightB;
		int topA, topB;
		int bottomA, bottomB;

		//Calculate the sides of rect A
		leftA = x;
		rightA = x + van_player.w;
		topA = y;
		bottomA = y + van_player.h;
		
		/*This will loop through 39 rects and check
		 and collisions with all rects*/
		for (int i = 0; i < 1; i++)
		{
			//Calculate the sides of rect B
			leftB = blocks[i].x;
			rightB = blocks[i].x + blocks[i].w;
			topB = blocks[i].y;
			bottomB = blocks[i].y + blocks[i].h;

			//If any of the sides from A are outside of B
			if (bottomA <= topB)
				return false;
			if (topA >= bottomB)
				return false;
			if (rightA <= leftB)
				return false;
			if (leftA >= rightB)
				return false;
		}
		return true;
	}

	void move(SDL_Renderer* gRenderer, SDL_Event e, SDL_Rect* blocks)
	{
		if (e.type = SDL_KEYDOWN)
		{
			switch (e.key.keysym.sym)
			{
				case SDLK_LEFT:
					x -= 2;
					if (!collision(blocks,e)) // if no collision:
					{
						std::cout << x << " " << y << '\n';
						/*This angle will only be modified if there
							is a turn, this condition will be checked 
							once we have the road tiles.*/
						angle = 180.0;
						break;
					}
					else { x += 2; }
					
				case SDLK_RIGHT:
					x += 2;
					if (!collision(blocks,e))
					{
						std::cout << x << " " << y << '\n';
						angle = 0.0;
						break;
					}
					else { x -= 2; }

				case SDLK_UP:
					y -= 2;
					if (!collision(blocks,e))
					{
						std::cout << x << " " << y << '\n';
						angle = -90.0;
						break;
					}
					else { y += 2; }
				
				case SDLK_DOWN:
					y += 2;
					if (!collision(blocks,e))
					{
						std::cout << x << " " << y << '\n';
						angle = 90.0;
						break;
					}
					else { y -= 2; }

				default:
					break;
			}
		}
	}
};
