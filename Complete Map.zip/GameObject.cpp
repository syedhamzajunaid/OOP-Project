#include "GameObject.h"
#include "Map.h"

GameObject::GameObject(){}

GameObject::GameObject(const char* spritesheet) 
{
	// Loads the texture with coords
    objTexture = LTexture::LoadTexture(spritesheet);
	srcrect.x = 1;
	srcrect.y = 54;
	srcrect.w = 30;
	srcrect.h = 20;

	pos.x = 0;
	pos.y = 91;

    destrect.x = pos.x;
    destrect.y = pos.y;
    destrect.w = srcrect.w;
    destrect.h = srcrect.h;
    angle = 0;
    collision = false;
	present = true;
}

GameObject::~GameObject()
{
    SDL_DestroyTexture(objTexture);
    objTexture = NULL;
}


void GameObject::Render()
{
	// Renders all objects on screen
	SDL_RenderCopyEx(GameLoop::grenderer, objTexture,&srcrect, &destrect, angle, NULL, SDL_FLIP_NONE);

	//for debugging, this will show the obj's rect
	/*SDL_SetRenderDrawColor(GameLoop::grenderer, 0xff, 0xff, 0xff, 0xff);
	SDL_RenderFillRect(GameLoop::grenderer, &destrect);*/
}

bool GameObject::check_collision(SDL_Rect B, SDL_Rect A)
{
	//The sides of the rectangles
	int leftA, leftB;
	int rightA, rightB;
	int topA, topB;
	int bottomA, bottomB;

	//Calculate the sides of rect A
	leftA = A.x;
	rightA = A.x + A.w;
	topA = A.y;
	bottomA = A.y + A.h;

	leftB = B.x;
	rightB = B.x + B.w;
	topB = B.y;
	bottomB = B.y + B.h;

	//If any of the sides from A are outside of B
	if (bottomA <= topB)
	{
		return false;
	}
	if (topA >= bottomB)
	{
		return false;
	}
	if (rightA <= leftB)
	{
		return false;
	}
	if (leftA >= rightB)
	{
		return false;
	}

	//If none of the sides from A are outside B
	return true;
}


void GameObject::Update(SDL_Event e, SDL_Rect* blocks)
{
    if (e.type = SDL_KEYDOWN)
    {
        if(e.key.keysym.sym == SDLK_LEFT)
        {
            if(angle != 180)
            {
                angle = 180;
            }
            pos.x = pos.x - 2;
            destrect.x = pos.x;
            for(int i = 0; i < 41; i++)
            {
                if(check_collision(blocks[i], destrect))
                {
                    collision = true;
                    break;
                }
            }
			if (collision)
			{
				pos.x = pos.x + 2;
				destrect.x = pos.x;
				collision = false;
			}
        }

       else if(e.key.keysym.sym == SDLK_RIGHT)
        {
            if(angle != 0)
            {
                angle = 0;
            }
            pos.x = pos.x + 2;
            destrect.x = pos.x;
            for(int i = 0; i < 41; i++)
            {
                if(check_collision(blocks[i], destrect))
                {
                    collision = true;
                    break;
                }
            }
            if(collision)
            {
                pos.x = pos.x - 2;
                destrect.x = pos.x;
                collision = false;
            }
        }

        else if(e.key.keysym.sym == SDLK_UP)
        {
            if(angle != -90)
            {
                angle = -90;
            }
            pos.y = pos.y - 2;
            destrect.y = pos.y;
            for(int i = 0; i < 41; i++)
            {
                if(check_collision(blocks[i], destrect))
                {
                    collision = true;
                    break;
                }
            }
            if(collision)
            {
                pos.y = pos.y + 2;
                destrect.y = pos.y;
                collision = false;
            }
        }

        else if(e.key.keysym.sym == SDLK_DOWN)
        {
            if(angle != 90)
            {
                angle = 90;
            }
            pos.y = pos.y + 2;
            destrect.y = pos.y;
            for(int i = 0; i < 41; i++)
            {
                if(check_collision(blocks[i], destrect))
                {
                    collision = true;
                    break;
                }
            }
            if(collision)
            {
                pos.y = pos.y - 2;
                destrect.y = pos.y;
                collision = false;
            }
        }
    }
}
