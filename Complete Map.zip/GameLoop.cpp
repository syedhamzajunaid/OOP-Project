#include "GameLoop.h"
#include "LTexture.h"
#include "Map.h"

GameObject *playervan;
SDL_Renderer* GameLoop::grenderer = NULL;
Map *city_map;

GameLoop::GameLoop()
{}

GameLoop::~GameLoop()
{}

void GameLoop::init(const char* title, int posx, int posy, int width, int height, bool fullscreen)
{
    int flags = 0;
    if(fullscreen == true)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

	//Initialize SDL
	if( SDL_Init( SDL_INIT_EVERYTHING ) < 0 )
	{
		printf( "SDL could not initialize! SDL_Error: %s\n", SDL_GetError() );
		isrunning = false;
	}
	else
    {
        gwindow = SDL_CreateWindow(title, posx, posy, width, height, flags);
        if( gwindow == NULL )
		{
			printf( "Window could not be created! SDL_Error: %s\n", SDL_GetError() );
			isrunning = false;
		}
		else
		{
			grenderer = SDL_CreateRenderer(gwindow, -1, 0);
			if(grenderer == NULL)
            {
                printf( "Renderer could not be created! %s\n", SDL_GetError() );
            }
            else
            {
                SDL_SetRenderDrawColor(grenderer, 255, 255, 255, 255);
            }
            isrunning = true;
		}

    }
    playervan = new GameObject("Assets/Player.png");
    city_map = new Map("Assets/Map.png");
}

void GameLoop::update()
{
    city_map->Update();
}

void GameLoop::handleevents()
{
    SDL_Event e;
    int x, y;
    SDL_GetMouseState( &x, &y );
    while(SDL_PollEvent(&e)!=0)
    {
        if(e.type == SDL_QUIT)
        {
            isrunning = false;
            break;
        }
        else if(e.type == SDL_MOUSEBUTTONDOWN)
        {
            cout << x << " " << y << endl;
        }
        else
        {
            playervan->Update(e, city_map->blocks);
        }
    }
}


void GameLoop::render()
{
    SDL_RenderClear(grenderer);
    city_map->Render();
	playervan->Render();
    this->handleevents();   
    SDL_RenderPresent(grenderer);
}

void GameLoop::close()
{
    SDL_DestroyWindow(gwindow);
    SDL_DestroyRenderer(grenderer);
    SDL_Quit();
    cout << "game cleaned" << endl;
}
