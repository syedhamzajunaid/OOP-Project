#pragma once
#include"Node.h"

class Queue
{
private:
    Node* head;
    Node* tail;
public:
    Queue();
    ~Queue();
    void Enqueue(GameObject*);
    void Dequeue();
};
