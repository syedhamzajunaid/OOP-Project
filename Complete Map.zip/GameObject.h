#pragma once
#include "GameLoop.h"
#include "Point.h"

class GameObject
{
    public:
        GameObject();
        GameObject(const char* spritesheet);
        ~GameObject();
        void Update(SDL_Event e, SDL_Rect* blocks);
        void Render();
        int xpos_getter(){return pos.x;}
        int ypos_getter(){return pos.y;}
        void xpos_setter(int x){pos.x = pos.x + x;}
        void ypos_setter(int y){pos.y = pos.y + y;}
        void angle_setter(double angle){this->angle = angle;}
        bool check_collision(SDL_Rect A, SDL_Rect B);
		bool isPresent() { return present;}

    protected:
		Point pos;
        double angle;
        SDL_Texture* objTexture;
        SDL_Rect srcrect, destrect;
        bool collision;
		bool present;

};


