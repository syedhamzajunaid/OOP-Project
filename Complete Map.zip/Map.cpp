#include "Map.h"
#include "LTexture.h"


Map::Map(const char* spritesheet)
{
    map_texture = LTexture::LoadTexture(spritesheet);
    
	blocks[0] = { 0,0,153,85 };
	blocks[1] = { 192,0,100,85 };
	blocks[2] = { 333,0, 166,85 };
	blocks[3] = { 537,0, 129,85 };
	blocks[4] = { 704,0,103,85 };
	blocks[5] = { 845,0,177,192 };
    blocks[6] = { 0,115,76,67};
	blocks[7] = { 115,115,204,66 };
    blocks[8] = {359,115,127,191};
    blocks[9] = {525,115,281,76};
    blocks[10] = {845,220,141,87};
    blocks[11] = {38,211,115,67};
    blocks[12] = {192,211,127,124};
    blocks[13] = {358,335,484-358,441-335};
    blocks[14] = {486,414,127,27};
    blocks[15] = {525,305,615-524,383-305};
    blocks[16] = {525,220,805-525,278-220};
    blocks[17] = {640,220,716-640,278-220};
    blocks[18] = {755,220,506-755,276-220};
    blocks[19] = {653,307,806-653,382-307};
    blocks[20] = {845,336,1021-845,450-336};
	blocks[21] = { 38,306,153,29 };
	blocks[22] = { 652,412,805-652,480-412 };
	blocks[23] = { 38,365,319-38,509-365 };
	blocks[24] = { 358,470,613-358,537-470 };
	blocks[25] = { 654,508,807-653,613-508 };
	blocks[26] = { 846,480,985-846,613-480 };
	blocks[27] = { 846,517,986-856,614-547 };
	blocks[28] = { 0,536,87,672-536 };
	blocks[29] = { 89,623,127-89,672-623};
	blocks[30] = { 128,538,180-128,594-538 };
	blocks[31] = { 217,537,319-217,595-537 };
	blocks[32] = { 357,566,614-357,614-566 };
	blocks[33] = { 500,643,806-500,681-643 };
	blocks[34] = {166,624,320-166,671-624};
	blocks[35] = { 38,700,90,39 };
	blocks[36] = { 166,700,155,38};
	blocks[37] = { 358,643,104,97 };
	blocks[38] = { 499,710,78,58 };
	blocks[39] = { 615,710,193,58 };
	blocks[40] = { 845,643,142,97 };
}

Map::~Map()
{}

void Map::Update()
{
    pos.x = pos.y = 0;
}

void Map::Render()
{

	SDL_RenderCopy(GameLoop::grenderer, map_texture, NULL, NULL);

	// for debugging, show these rects on map
   /* for(int i = 0; i < 41; i++)
    {
    SDL_SetRenderDrawColor(GameLoop::grenderer, 0xff, 0xff, 0xff, 0xff);
    SDL_RenderFillRect(GameLoop::grenderer, &(blocks[i]));
    }*/

}
