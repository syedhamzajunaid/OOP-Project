#pragma once
#include"LTexture.h"
#include "SDL.h"

class Rubble:public Obstacles
{
private:
	int x, y; // position, have to be replaced with point
	SDL_Rect rubble;
    bool alive ;
    float angle = 0.0 ;
 public:
    Rubble(LTexture* image, int x, int y);
    ~Rubble() ;
    void Render(LTexture* image, SDL_Renderer* gRenderer);
};
