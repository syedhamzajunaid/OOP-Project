#pragma once
#include "GameObject.h"

class Vehicles: public GameObject
{
protected:
    int speed_x, speed_y = 0 ;
    int xpos , ypos ;
    float friction ;
public:
    Vehicles() : GameObject() {};
    ~Vehicles()
    {
        std::cout << "Vehicle destroyed." << std::endl ;
    } ;
    virtual void Render() = 0 ;
    virtual void Move(SDL_Event e,SDL_Rect* blocks) = 0 ;
    virtual void Update(SDL_Event e,SDL_Rect*blocks) = 0 ;
};
