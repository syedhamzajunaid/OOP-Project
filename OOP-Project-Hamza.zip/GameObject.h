#pragma once
#include "GameLoop.h"

class GameObject
{
    public:
        GameObject();
        GameObject(const char* spritesheet);
        ~GameObject();
        virtual void Update(SDL_Event e, SDL_Rect* blocks);
        virtual void Render();
        int xpos_getter(){return xpos;}
        int ypos_getter(){return ypos;}
        void xpos_setter(int x){xpos = xpos + x;}
        void ypos_setter(int y){ypos = ypos + y;}
        void angle_setter(double angle){this->angle = angle;}
        bool check_collision(SDL_Rect A, SDL_Rect B);

    protected:
        int xpos, ypos;
        double angle;
        SDL_Texture* objTexture;
        SDL_Rect srcrect, destrect;
        bool collision;

};


