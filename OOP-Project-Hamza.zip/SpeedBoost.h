#pragma once


class SpeedBoost:public Powerups
{
public:
    SpeedBoost(LTexture* image, float x, float y) ;
    ~SpeedBoost()
     void Render();
};
