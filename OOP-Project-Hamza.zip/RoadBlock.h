#pragma once
#include"SDL.h"
#include"LTexture.h"

class RoadBlock: public Obstacles
{
private:
    int x,y ;// position, have to be replaced with point
	SDL_Rect road_block;
	bool alive ;
public:
    Roadblock() ;
    ~Roadblock() ;
    void Render() ;
};
