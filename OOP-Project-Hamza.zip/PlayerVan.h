#pragma once
#include "Vehicles.h"



class PlayerVan:public Vehicles
{
private:
    float time, fuel = 0 ;
    //static PlayerVan* player = new PlayerVan("Assets/Player.png") ;

//    static PlayerVan* player;
public:
    PlayerVan(const char* path) ;
    ~PlayerVan() ;
    float GetFuel() ;
    void  SetFuel(float new_fuel) ;
    float GetTime() ;
    //static PlayerVan* GetPlayer() ;
    void SetTime(float new_time) ;
    void Move(SDL_Event e, SDL_Rect* blocks) ;
    void Render() ;
    void Update(SDL_Event e,SDL_Rect* blocks);
    bool CheckCollision(SDL_Rect A, SDL_Rect B) ;
    void Update_Up() ;
    void Update_Down() ;
    void Update_Left() ;
    void Update_Right() ;
} ;
