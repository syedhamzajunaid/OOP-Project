#pragma once
#include "GameObject.h"

class Powerups:public GameObject
{
protected:
    int strength;
    int lifetime;
public:
    Powerups() ;
    ~Powerups() ;
    virtual void Render() = 0;
    virtual void Update() = 0;
};
