#include "GameLoop.h"
#include "LTexture.h"
#include "Map.h"
#include "GameObject.h"
#include "Vehicles.h"
#include "PlayerVan.h"

Vehicles* player ;
SDL_Renderer* GameLoop::grenderer = NULL;
Map *level;

GameLoop::GameLoop()
{

}

GameLoop::~GameLoop()
{}

void GameLoop::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{
    int flags = 0;
    if(fullscreen == true)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

	//Initialize SDL
	if( SDL_Init( SDL_INIT_EVERYTHING ) < 0 )
	{
		printf( "SDL could not initialize! SDL_Error: %s\n", SDL_GetError() );
		isrunning = false;
	}
	else
    {
        gwindow = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
        if( gwindow == NULL )
		{
			printf( "Window could not be created! SDL_Error: %s\n", SDL_GetError() );
			isrunning = false;
		}
		else
		{
			grenderer = SDL_CreateRenderer(gwindow, -1, 0);
			if(grenderer == NULL)
            {
                printf( "Renderer could not be created! %s\n", SDL_GetError() );
            }
            else
            {
                SDL_SetRenderDrawColor(grenderer, 255, 255, 255, 255);
            }
            isrunning = true;
		}

    }
//    playervan = new GameObject("Assets/Player.png");
    level = new Map("Assets/Map.png");
   player = new PlayerVan("Assets/Player.png") ;
}

void GameLoop::update()
{
    SDL_Event e;
    level->Update();
}

void GameLoop::handleevents()
{
    SDL_Event e;
    int x, y;
    SDL_GetMouseState( &x, &y );
    while(SDL_PollEvent(&e)!=0)
    {
        if(e.type == SDL_QUIT)
        {
            isrunning = false;
            break;
        }
        else
        {
            player->Update(e,level->blocks) ;
        }
    }
}


void GameLoop::render()
{
    SDL_RenderClear(grenderer);
    level->Render();
    this->handleevents();
   // playervan->Render();
    player->Render() ;
    SDL_RenderPresent(grenderer);
}

void GameLoop::close()
{
    SDL_DestroyWindow(gwindow);
    SDL_DestroyRenderer(grenderer);
    SDL_Quit();
    cout << "game cleaned" << endl;
}
