#include "PlayerVan.h"
#include "SDL.h"

//---The constructor basically loads the texture of the object.
PlayerVan::PlayerVan(const char* path):Vehicles()
{
    //Load texture.
    objTexture = LTexture::LoadTexture(path);
    std::cout << "Player Van texture loaded." << std::endl ;
    xpos = 0;
    ypos = 72 ;

    srcrect.h = 23 ;
    srcrect.w = 30;
    srcrect.x = xpos;
    srcrect.y = ypos;

    destrect.x = xpos;
    destrect.y = ypos;
    destrect.w = 20;
    destrect.h = 20;
 }
//---Destructor.
 PlayerVan::~PlayerVan()
 {
     std::cout << "Player Van destroyed." << std::endl ;
 }
//---Getter functions
float PlayerVan::GetFuel()
{
    return fuel ;
}

float PlayerVan::GetTime()
{
    return time ;
}
//---Setter functions
void PlayerVan::SetFuel(float new_fuel)
{
    fuel = new_fuel ;
}
void PlayerVan::SetTime(float new_time)
{
    time = new_time ;
}
//---Inherited (Polymorphic) methods.
void PlayerVan::Render()
{
     SDL_RenderCopyEx(GameLoop::grenderer, objTexture, NULL, &destrect, angle, NULL, SDL_FLIP_NONE);
}

void PlayerVan::Update(SDL_Event e,SDL_Rect* blocks)
{
    this->Move(e,blocks) ;
}



bool PlayerVan::CheckCollision(SDL_Rect A, SDL_Rect B)
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect A
    leftA = A.x;
    rightA = A.x + A.w;
    topA = A.y;
    bottomA = A.y + A.h;

    leftB = B.x;
    rightB = B.x + B.w;
    topB = B.y;
    bottomB = B.y + B.h;
    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }
    //If none of the sides from A are outside B
    return true;
}


void PlayerVan::Move(SDL_Event e,SDL_Rect* blocks)
{
    if (e.type = SDL_KEYDOWN)
		{
			switch (e.key.keysym.sym)
			{
				case SDLK_LEFT:
                if(angle != -90)
                {
                    angle = -90;
                }
                xpos -=  2;
                destrect.x = xpos;
                for(int i = 0; i < 23; i++)
                {
                    if(PlayerVan::CheckCollision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    xpos += 2;
                    destrect.x = xpos;
                    collision = false;
                }
                std :: cout << "Left: " << xpos << "," << ypos << std::endl ;
                break;

				case SDLK_RIGHT:
                if(angle != 90)
                {
                    angle = 90;
                }
                xpos = xpos + 2;
                destrect.x = xpos;
                for(int i = 0; i < 23; i++)
                {
                    if(PlayerVan::CheckCollision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    xpos = xpos - 2;
                    destrect.x = xpos;
                    collision = false;
                }
                std :: cout << "Right: " << xpos << "," << ypos << std::endl ;
                break ;

				case SDLK_UP:
                if(angle != 0)
                {
                    angle = 0;
                }
                ypos = ypos - 2;
                destrect.y = ypos;
                for(int i = 0; i < 23; i++)
                {
                    if(PlayerVan::CheckCollision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    ypos = ypos + 2;
                    destrect.y = ypos;
                    collision = false;
                }
                std :: cout << "Up: " << xpos << "," << ypos << std::endl ;
                break;
				case SDLK_DOWN:
                if(angle != 180)
                {
                    angle = 180;
                }
                ypos = ypos + 2;
                destrect.y = ypos;
                for(int i = 0; i < 20; i++)
                {
                    if(PlayerVan::CheckCollision(blocks[i], destrect))
                       {
                           collision = true;
                           break;
                       }
                }
                if(collision)
                {
                    ypos = ypos - 2;
                    destrect.y = ypos;
                    collision = false;
                }
                std :: cout << "Down: " << xpos << "," << ypos << std::endl ;
                break;

				default:
					break;
			}
		}
}
/*
PlayerVan* PlayerVan::GetPlayer()
{
    return player ;
}
*/
