#pragma once

class TimeBoost.h: public Powerups
{
  TimeBoost(LTexture* image, float x, float y) ;
  ~TimeBoost() ;
  void Render();
};
