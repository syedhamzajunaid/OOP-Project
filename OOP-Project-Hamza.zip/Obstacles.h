#pragma once
#include "GameObject.h"

class Obstacles:public GameObject
{
protected:
    int strength ;
public:
    Obstacle(): GameObject() {}  ;
    ~Obstacles() {};
    virtual void Render() = 0 ;
    virtual void Update() = 0 ;
};
