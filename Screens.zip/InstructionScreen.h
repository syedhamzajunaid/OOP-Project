#pragma once

#include "Screen.h"

class InstructionScreen:public Screen
{
public:
    InstructionScreen(LTexture*,LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~InstructionScreen();
};
