#include "InstructionScreen.h"
InstructionScreen::InstructionScreen(LTexture* bgImage,LTexture* fontSprite) : Screen(bgImage,fontSprite)
{
    this->bgImage=bgImage;
}

void InstructionScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    std::cout<<"Instruction screen coming"<<std::endl;
    bgImage->RenderTexture( 0, 0,gRenderer,NULL);
}

InstructionScreen::~InstructionScreen()
{
    std::cout<<"Instruction screen Destroyed"<<std::endl;
}

