#include "MenuScreen.h"


MenuScreen::MenuScreen(LTexture* bgImage, LTexture* fontSprite) : Screen(bgImage,fontSprite)
{
    this->bgImage = bgImage;
    std::string ButtonText[4]={"CONTINUE", "NEW GAME","EXIT","MUSIC"}; //Text on the buttons
    float posX=(float)width/2;
    float posY=((float)height/2);
    ButtonCount = 4;
    buttons = new Button[4];
    for(int i=0; i<3; i++)
    {
        buttons[i] = Button(fontSprite,ButtonText[i],posX, posY + 50);
        posY+=100;
    }
    buttons[3]= Button(fontSprite,ButtonText[3],posX+350, posY );

}

void MenuScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    bgImage->RenderTexture( 0, 0,gRenderer, NULL);
    for(int i=0; i<ButtonCount; i++)
    {
        buttons[i].Render(gRenderer);
    }
}

MenuScreen::~MenuScreen()
{
    std::cout<<"Menu Screen Destroyed"<<endl;
}

