#include "StartScreen.h"

StartScreen::StartScreen(LTexture* bgImage,LTexture* fontSprite) : Screen(bgImage,fontSprite)
{
    this->bgImage=bgImage;
}

void StartScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
     bgImage->RenderTexture( 0, 0,gRenderer,NULL);
}

StartScreen::~StartScreen()
{
    std::cout<<"Splash Screen Destroyed"<<std::endl;
}

