#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "Screen.h"
#include "StartScreen.h"
#include "MenuScreen.h"
#include "InstructionScreen.h"
#include "LTexture.h"
#include "Button.h"
#include <SDL_mixer.h>
using namespace std;

bool init();
bool loadMedia();
void close();
void setAlpha();

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

const int SCREEN_WIDTH =  1024;
const int SCREEN_HEIGHT = 768;

//Textures for images
LTexture gFontTexture;
LTexture gStart;//start('OOP Project') image
LTexture gMainMenuTexture;
LTexture gInstructionTexture;

//musics
Mix_Music* MenuScreenMusic= NULL;
Mix_Music* InstructionScreenMusic= NULL;
Mix_Chunk* ButtonClickSsound= NULL;


//Alpha(Opacity) Modulation component
Uint8 a = 255; //one component is set to full opaque
Uint8 b = 0; //other is full transparent
Uint8 button = 220;//alpha value for buttons
Uint8 button_screen = 200; //for controlling alpha value of other textures


int main( int argc, char* args[] )
{
    if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
			//Main loop flag
			bool quit = false;
            //flags to check which screen is running

            bool StartRunning = true;
            bool menuRunning = false;
            bool instructionRunning = false;

            long int frame = 0;

            bool mouseClicked = false; //flag indicating mouse click
            Button* buttons = NULL;   //will hold button(s) on the screen
            int x,y;


            StartScreen Start(&gStart,&gFontTexture);
            MenuScreen mainMenu(&gMainMenuTexture,&gFontTexture/*,&gButtonScreen*/);
            InstructionScreen instructionMenu(&gInstructionTexture,&gFontTexture);
			//Event handler
			SDL_Event e;
			//While application is running
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
					SDL_GetMouseState(&x,&y);
                    if (e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                            mouseClicked=true;
                    }
                    if (e.type == SDL_MOUSEMOTION) //to handle all mouse motion events for all screens
                    {
                        mainMenu.mouseMotionEvents(x,y);
                    }
                    if(e.type == SDL_MOUSEBUTTONUP && mouseClicked) //to handle all mouse click events for all screens
                    {
                        mainMenu.mouseClickEvents(x,y,ButtonClickSsound);
                        mouseClicked = false;
                    }
                    if (menuRunning)
                    {
                        buttons = mainMenu.getButtons();
                        for (int i = 0; i < mainMenu.getButtonCount(); i++)
                        {
                            if(buttons[i].getText() == "NEW GAME" && buttons[i].clicked())
                            {
                                //game screen will load
                                cout<<"new game button"<<endl;
                                instructionRunning= true;
                                menuRunning=false;

                                break;
                            }
                            else if (buttons[i].getText() == "CONTINUE" && buttons[i].clicked())
                            {
                                menuRunning = false;
                                break;

                            }
                            else if (buttons[i].getText() == "EXIT"  && buttons[i].clicked())
                            {
                                quit=true;
                                break;
                            }
                            else if (buttons[i].getText() == "MUSIC"  && buttons[i].clicked())
                            {
                                if( Mix_PausedMusic() == 1 )
                                {
                                    //Resume the music
                                    Mix_ResumeMusic();
                                }
                                //If the music is playing
                                else
                                {
                                    //Pause the music
                                    Mix_PauseMusic();
                                }
                                break;
                            }
                        }
                    }
				}
                //Clear screen
				SDL_SetRenderDrawColor( gRenderer,  0, 0, 0, 0 );
				SDL_RenderClear( gRenderer );

                if(menuRunning)     ///checks if Main Menu Screen is running
                {
                    //if transition to excerpt is called, start fading the menu-screen.
                    //Mix_PlayMusic(MenuScreenMusic,-1);
                    if (MenuScreenMusic)
                    {
                        Mix_PlayMusic(MenuScreenMusic,-1);
                        MenuScreenMusic = false;
                    }
                    gFontTexture.setAlpha(button);

                    //gMainMenuTexture.setAlpha(a);

                    mainMenu.Render(frame,gRenderer); //render main menu
                }
                if(StartRunning)       ///checks if Splash screen is running
                {
                    gStart.setAlpha(a);     ///Splash Screen fades out with a decreasing
                    Start.Render(frame, gRenderer);       ///Rendering Splash Screen
                    if(a == 0)
                    {
                        //Mix_PlayChannel(-1, screenTransition, 0);
                        StartRunning = false;    ///indicates the end of splash screen run
                        menuRunning = true;
                        a = 255; //reset
                        b = 0; //reset
                    }
                }
                if(instructionRunning )
                {
                    //cout<<"instruction running"<<endl;
                    //gInstructionTexture.setAlpha(b);     ///Splash Screen fades out with a decreasing
                    instructionMenu.Render(frame, gRenderer);       ///Rendering Splash Screen
                    //Mix_PlayMusic(InstructionScreenMusic,1);
                    if (InstructionScreenMusic)
                    {
                        Mix_PlayMusic(InstructionScreenMusic,1);
                        InstructionScreenMusic= false;
                    }
                    //instructionRunning=false;

                }



                setAlpha(); //to decrement a and increment b
                frame++;
                if (frame % 50 == 0)
                {
                    frame = 0;
                }
				//Update screen
				SDL_RenderPresent( gRenderer );
			}
		}
	}
	//Free resources and close SDL
	close();
    return 0;

}

bool init()
{
	///Initialization flag
	bool success = true;

	///Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		///Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		///Create window
		gWindow = SDL_CreateWindow( "Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}

		else
		{
			///Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
			else
			{
				///Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0 );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
                //Initialize SDL_mixer
                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
                {
                    printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
                    success = false;
                }
			}
		}
	}
	return success;
}

bool loadMedia()
{
	///Loading success flag
	bool success = true;
	if( !gFontTexture.LoadFromFile( "imagesd.png", gRenderer) )//button and text sprite sheet
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        //Set standard alpha blending
        gFontTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !gStart.LoadFromFile( "startscreen.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gStart.setBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !gInstructionTexture.LoadFromFile( "back.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gInstructionTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
	if( !gMainMenuTexture.LoadFromFile( "MenuScreenses.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	else
    {
        ///Set standard alpha blending
        gMainMenuTexture.setBlendMode( SDL_BLENDMODE_BLEND );
    }
    //Sound effects loading
    MenuScreenMusic = Mix_LoadMUS( "pacman_intermission.wav" );
    if( MenuScreenMusic == NULL )
    {
        printf( "Failed to load menu screen sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    InstructionScreenMusic = Mix_LoadMUS( "coolgames.wav" );
    if( MenuScreenMusic == NULL )
    {
        printf( "Failed to load menu screen sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    ButtonClickSsound  = Mix_LoadWAV( "button_click.wav" );
    if( ButtonClickSsound == NULL )
    {
        printf( "Failed to load buttonClick sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
    return success;
}

void close()
{
	///Free loaded images
    //gFontTexture.Free();
	gStart.Free();
    gMainMenuTexture.Free();
    Mix_FreeChunk( ButtonClickSsound );
    ButtonClickSsound = NULL;
    Mix_FreeMusic( MenuScreenMusic );
    MenuScreenMusic = NULL;
    Mix_FreeMusic( InstructionScreenMusic );
    InstructionScreenMusic = NULL;
	///Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	///Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}
void setAlpha()
{
    ///Cap if below 0
    if( a - 3 < 0 )
    {
        a = 0;
    }
    ///Decrement otherwise
    else
    {
        a -= 3;
    }
    ///Cap if above 255
    if( b+ 3 > 255 )
    {
        b=255;
    }
    ///Increment otherwise
    else
    {
        b += 3;
    }
}
