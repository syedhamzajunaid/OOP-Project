#pragma once

#include "Screen.h"

class StartScreen : public Screen
{
public:
    StartScreen(LTexture*,LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~StartScreen();
};
