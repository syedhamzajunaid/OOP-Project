#pragma once
#include "Screen.h"

class MenuScreen : public Screen
{
private:
    LTexture* buttonScreen; //the small screen over which buttons are drawn
public:
    MenuScreen(LTexture*,LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~MenuScreen();
};
